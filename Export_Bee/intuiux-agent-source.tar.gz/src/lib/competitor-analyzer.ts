// Competitor Analyzer v3.0 - CONTEXT-AWARE FALLBACK ANALYSIS
// Generates competitor analysis from extracted idea context when web search is unavailable
// Uses industry, functions, value proposition, audience for smarter analysis

import { ExtractedIdea } from './idea-extractor';

// ═══════════════════════════════════════════════════════════════
// INTERFACES
// ═══════════════════════════════════════════════════════════════

export interface CompetitorAnalysisResult {
  productName: string;
  industryName: string;
  marketSize: string;
  marketTrends: string[];
  directCompetitors: {
    name: string;
    url: string;
    country: string;
    description: string;
    features: string[];
    pricing: string;
    targetAudience: string;
    swotHtml: string;
    scores: {
      functionality: number;
      price: number;
      ux: number;
      support: number;
    };
  }[];
  indirectCompetitors: {
    name: string;
    description: string;
    approach: string;
    overlap: string;
    differentiation: string;
  }[];
  comparisonTable: string;
  differentiationOpportunities: string[];
  positioningRecommendation: string;
  contextUsed: string[];
}

// ═══════════════════════════════════════════════════════════════
// SWOT ANALYSIS - Generate from context
// ═══════════════════════════════════════════════════════════════

function generateSWOTTable(
  strengths: string[],
  weaknesses: string[],
  opportunities: string[],
  threats: string[]
): string {
  return `
| Сильные стороны | Слабые стороны |
|---|---|
| ${strengths.map(s => `✓ ${s}`).join('<br>')} | ${weaknesses.map(w => `✗ ${w}`).join('<br>')} |

| Возможности | Угрозы |
|---|---|
| ${opportunities.map(o => `→ ${o}`).join('<br>')} | ${threats.map(t => `⚠ ${t}`).join('<br>')} |
`;
}

// ═══════════════════════════════════════════════════════════════
// INDUSTRY-COMPETITOR MAPPING
// Maps common industry keywords to known competitor types
// ═══════════════════════════════════════════════════════════════

interface IndustryCompetitorMapping {
  keywords: string[];
  competitors: {
    name: string;
    url: string;
    description: string;
    features: string[];
    pricing: string;
    strengths: string[];
    weaknesses: string[];
  }[];
  indirectCompetitors: {
    name: string;
    description: string;
    approach: string;
    overlap: string;
    differentiation: string;
  }[];
  marketSize: string;
  trends: string[];
}

const INDUSTRY_MAPPINGS: IndustryCompetitorMapping[] = [
  {
    keywords: ['телефон', 'звонок', 'атс', 'облачн', 'siem', 'сиэрэм', 'витрин', 'статистик звонок', 'колл-центр', 'коллцентр', 'оператор связ'],
    competitors: [
      {
        name: 'Манго Телеком',
        url: 'https://mango-office.ru',
        description: 'Облачная АТС и omnichannel-платформа для бизнеса',
        features: ['Облачная АТС', 'Аналитика звонков', 'Колл-центр', 'Интеграции CRM', 'Виртуальные номера'],
        pricing: 'Подписка от 3 900 ₽/мес',
        strengths: ['Широкий функционал', 'API', 'Российский рынок', 'Интеграции'],
        weaknesses: ['Сложный интерфейс', 'Высокая цена', 'Долгий онбординг'],
      },
      {
        name: 'Zadarma',
        url: 'https://zadarma.com',
        description: 'Облачная телефония и виртуальные номера',
        features: ['Виртуальные номера', 'IP-телефония', 'АТС', 'Запись звонков'],
        pricing: 'От $0/мес + минуты',
        strengths: ['Доступные цены', 'Международные номера', 'Простой старт'],
        weaknesses: ['Ограниченная аналитика', 'Слабый RU-саппорт', 'Базовый функционал'],
      },
      {
        name: 'UIS (ЮНИС)',
        url: 'https://uiscom.ru',
        description: 'Омниканальная коммуникационная платформа',
        features: ['Облачная АТС', 'Мессенджеры', 'Автозвонки', 'Речевая аналитика'],
        pricing: 'Подписка, от 5 000 ₽/мес',
        strengths: ['Речевая аналитика', 'Omnichannel', 'CRM интеграции', 'AI-функции'],
        weaknesses: ['Высокая стоимость', 'Сложная настройка', 'Долгое внедрение'],
      },
    ],
    indirectCompetitors: [
      { name: 'Битрикс24', description: 'CRM с встроенной телефонией', approach: 'Встроенная АТС в CRM', overlap: 'Звонки и аналитика', differentiation: 'Не специализированная аналитика' },
      { name: 'АмоCRM', description: 'CRM с телефонным модулем', approach: 'Модуль телефонии в CRM', overlap: 'Управление звонками', differentiation: 'Ограниченная статистика' },
      { name: 'Yclients', description: 'Управление записью с телефонной связью', approach: 'Встроенная связь в сервисе', overlap: 'Обработка звонков', differentiation: 'Узкая ниша - запись клиентов' },
    ],
    marketSize: '$2.1 млрд рынок UCaaS в РФ (2024)',
    trends: ['AI-аналитика звонков', 'Omnichannel', 'Речевая аналитика', 'Интеграции с CRM'],
  },
  {
    keywords: ['витрин', 'дашборд', 'dashboard', 'аналитик', 'метрик', 'виджет', 'репорт'],
    competitors: [
      {
        name: 'Yandex DataLens',
        url: 'https://datalens.yandex.ru',
        description: 'BI-сервис для визуализации данных и аналитики',
        features: ['Дашборды', 'Визуализация данных', 'SQL-редактор', 'Коннекторы к БД'],
        pricing: 'Бесплатно до 1 ГБ данных',
        strengths: ['Бесплатный tiers', 'Экосистема Яндекса', 'Мощный SQL', 'Российский сервис'],
        weaknesses: ['Сложный для нетехнических пользователей', 'Ограниченные шаблоны', 'Долгое обучение'],
      },
      {
        name: 'Superset (Apache)',
        url: 'https://superset.apache.org',
        description: 'Open-source платформа для бизнес-аналитики',
        features: ['Интерактивные дашборды', 'SQL-редактор', 'Визуализации', 'Кеширование'],
        pricing: 'Open Source (бесплатно)',
        strengths: ['Бесплатно', 'Гибкий', 'Активное сообщество', 'Много коннекторов'],
        weaknesses: ['Требует DevOps', 'Сложная установка', 'Нет встроенного ETL'],
      },
      {
        name: 'Grafana',
        url: 'https://grafana.com',
        description: 'Платформа для визуализации метрик и мониторинга',
        features: ['Дашборды', 'Алертинг', 'Графики', 'Плагины', 'Templating'],
        pricing: 'Open Source + Cloud от $0',
        strengths: ['Мощные графики', 'Алертинг', 'Гибкость', 'Сообщество'],
        weaknesses: ['Технический фокус', 'Не для бизнес-пользователей', 'Сложный start'],
      },
    ],
    indirectCompetitors: [
      { name: 'Excel / Google Sheets', description: 'Универсальные таблицы', approach: 'Ручной анализ', overlap: 'Визуализация данных', differentiation: 'Нет автоматизации, ручные данные' },
      { name: 'Power BI', description: 'BI-платформа Microsoft', approach: 'BI-аналитика', overlap: 'Дашборды', differentiation: 'Не российский, сложная интеграция' },
      { name: 'Tableau', description: 'Платформа визуализации данных', approach: 'BI-аналитика', overlap: 'Аналитика', differentiation: 'Дорогая, не российский' },
    ],
    marketSize: '$8.2 млрд рынок BI (глобально, 2024)',
    trends: ['AI-аналитика', 'Embedded analytics', 'Self-service BI', 'Real-time данные'],
  },
  {
    keywords: ['ecommerce', 'магазин', 'маркетплейс', 'торгов', 'товар', 'корзин', 'заказ'],
    competitors: [
      {
        name: 'Ozon',
        url: 'https://ozon.ru',
        description: 'Крупнейший маркетплейс России',
        features: ['Маркетплейс', 'Доставка', 'Реклама', 'Фулфилмент'],
        pricing: 'Комиссия 15-30%',
        strengths: ['Трафик', 'Доставка', 'Экосистема', 'Бренд'],
        weaknesses: ['Комиссии', 'Конкуренция продавцов'],
      },
      {
        name: 'Wildberries',
        url: 'https://wildberries.ru',
        description: 'Лидер маркетплейсов по охвату',
        features: ['Маркетплейс', 'Реклама', 'Логистика'],
        pricing: 'Комиссия 10-25%',
        strengths: ['Цены', 'Охват', 'Скорость'],
        weaknesses: ['Качество сервиса', 'Условия продавцов'],
      },
      {
        name: 'Яндекс.Маркет',
        url: 'https://market.yandex.ru',
        description: 'Платформа сравнения цен и покупок',
        features: ['Сравнение цен', 'Отзывы', 'Доставка'],
        pricing: 'Комиссия + реклама',
        strengths: ['Сравнение', 'Экосистема', 'Плюс'],
        weaknesses: ['Меньше продавцов', 'Логистика'],
      },
    ],
    indirectCompetitors: [
      { name: 'Социальные сети', description: 'VK, Instagram для продаж', approach: 'Контент-маркетинг', overlap: 'Привлечение', differentiation: 'Нет каталога' },
      { name: 'Avito', description: 'Доска объявлений', approach: 'Частные объявления', overlap: 'Поиск товаров', differentiation: 'Нет магазина' },
    ],
    marketSize: '$6 трлн глобально',
    trends: ['Маркетплейсы', 'Social commerce', 'Персонализация'],
  },
  {
    keywords: ['фитнес', 'тренер', 'тренировк', 'зал', 'спорт', 'абонемент'],
    competitors: [
      {
        name: 'FitStars',
        url: 'https://fitstars.ru',
        description: 'Сеть фитнес-клубов с приложением',
        features: ['Бронирование тренировок', 'Онлайн-тренировки', 'Трекинг', 'Питание'],
        pricing: 'Подписка от 2 500 ₽/мес',
        strengths: ['Офлайн + онлайн', 'Контент', 'Тренёры'],
        weaknesses: ['Ограниченная география', 'Высокая цена'],
      },
      {
        name: 'MyFitnessPal',
        url: 'https://myfitnesspal.com',
        description: 'Трекер питания и фитнеса',
        features: ['Подсчёт калорий', 'Трекинг тренировок', 'База продуктов', 'Сообщество'],
        pricing: 'Бесплатно + Premium $9.99/мес',
        strengths: ['Огромная база', 'Бесплатный tiers', 'Интеграции'],
        weaknesses: ['На английском', 'Ограниченные планы тренировок'],
      },
      {
        name: 'Yoga-приложения (Insight Timer)',
        url: 'https://insighttimer.com',
        description: 'Медитации и йога',
        features: ['Медитации', 'Йога-классы', 'Трекинг', 'Сообщество'],
        pricing: 'Бесплатно + Premium',
        strengths: ['Бесплатный контент', 'Сообщество', 'Гиды'],
        weaknesses: ['Не русский', 'Нет персонального тренера'],
      },
    ],
    indirectCompetitors: [
      { name: 'YouTube Fitness', description: 'Бесплатные видео тренировок', approach: 'Видео контент', overlap: 'Тренировки', differentiation: 'Нет трекинга, нет персонализации' },
      { name: 'Strava', description: 'Социальная сеть для спортсменов', approach: 'Социальный фитнес', overlap: 'Трекинг активности', differentiation: 'Не для тренировок в зале' },
    ],
    marketSize: '$96.7 млрд мировой рынок фитнес-приложений (2024)',
    trends: ['AI-тренёры', 'Гибридный фитнес', 'Wearable интеграции'],
  },
  {
    keywords: ['образовани', 'обучени', 'курс', 'edtech', 'лендинг', 'блог', 'статьи'],
    competitors: [
      {
        name: 'GetCourse',
        url: 'https://getcourse.ru',
        description: 'Платформа для создания и продажи онлайн-курсов',
        features: ['Конструктор курсов', 'Воронки продаж', 'CRM', 'Автоматизация'],
        pricing: 'Подписка от 3 000 ₽/мес',
        strengths: ['Полный цикл продаж', 'Автоматизация', 'Российский'],
        weaknesses: ['Устаревший дизайн', 'Сложный интерфейс', 'Высокая цена'],
      },
      {
        name: 'Antilatam',
        url: 'https://antilatam.com',
        description: 'Платформа онлайн-курсов',
        features: ['Конструктор', 'Платежи', 'Автоматизация', 'Вебинары'],
        pricing: 'Подписка от 1 990 ₽/мес',
        strengths: ['Простой старт', 'Доступная цена', 'Вебинары'],
        weaknesses: ['Ограниченный функционал', 'Меньше интеграций'],
      },
      {
        name: 'Tilda',
        url: 'https://tilda.cc',
        description: 'Конструктор сайтов и лендингов',
        features: ['Конструктор страниц', 'Шаблоны', 'E-commerce', 'Формы'],
        pricing: 'Бесплатно + от 750 ₽/мес',
        strengths: ['Простой в использовании', 'Красивые шаблоны', 'No-code'],
        weaknesses: ['Не для сложных проектов', 'Ограниченная кастомизация'],
      },
    ],
    indirectCompetitors: [
      { name: 'YouTube', description: 'Бесплатные обучающие видео', approach: 'Видео контент', overlap: 'Обучение', differentiation: 'Нет интерактивности, нет сертификации' },
      { name: 'Stepik', description: 'Платформа интерактивных курсов', approach: 'Интерактивное обучение', overlap: 'Контент', differentiation: 'Не для продажи, академический фокус' },
    ],
    marketSize: '$350 млрд рынок EdTech (глобально, 2024)',
    trends: ['Microlearning', 'AI-репетиторы', 'Геймификация', 'Hybrid learning'],
  },
];

// ═══════════════════════════════════════════════════════════════
// FIND BEST MATCHING INDUSTRY
// ═══════════════════════════════════════════════════════════════

function findBestIndustryMatch(idea: ExtractedIdea): IndustryCompetitorMapping | null {
  // Build a search text from all idea fields
  const searchText = [
    idea.name,
    idea.description,
    idea.industry,
    idea.subIndustry,
    idea.marketContext,
    ...idea.functions,
    idea.valueProposition,
    idea.userTypes,
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();

  let bestMatch: IndustryCompetitorMapping | null = null;
  let bestScore = 0;

  for (const mapping of INDUSTRY_MAPPINGS) {
    let score = 0;
    for (const keyword of mapping.keywords) {
      if (searchText.includes(keyword.toLowerCase())) {
        score += keyword.length; // Longer keywords = more specific = higher score
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = mapping;
    }
  }

  return bestMatch;
}

// ═══════════════════════════════════════════════════════════════
// MAIN ANALYSIS FUNCTION
// ═══════════════════════════════════════════════════════════════

export function analyzeCompetitors(idea: ExtractedIdea): CompetitorAnalysisResult {
  const contextUsed: string[] = [];
  
  if (idea.name) contextUsed.push(`Название: "${idea.name}"`);
  if (idea.industry) contextUsed.push(`Отрасль: "${idea.industry}"`);
  if (idea.functions.length > 0) contextUsed.push(`Функции: [${idea.functions.join(', ')}]`);
  if (idea.valueProposition) contextUsed.push(`Ценность: "${idea.valueProposition}"`);
  if (idea.userTypes) contextUsed.push(`Аудитория: "${idea.userTypes.split('\n')[0]}"`);

  // Find best matching industry
  const industryMatch = findBestIndustryMatch(idea);

  if (industryMatch) {
    contextUsed.push(`Отрасль определена: ${industryMatch.keywords.slice(0, 3).join(', ')}`);
    return buildAnalysisFromMapping(idea, industryMatch, contextUsed);
  }

  // Fallback: generic analysis
  return buildGenericAnalysis(idea, contextUsed);
}

function buildAnalysisFromMapping(
  idea: ExtractedIdea,
  mapping: IndustryCompetitorMapping,
  contextUsed: string[]
): CompetitorAnalysisResult {
  const directCompetitors = mapping.competitors.map(comp => {
    // Score based on function overlap
    const functionOverlap = idea.functions.filter(f => 
      comp.features.some(cf => cf.toLowerCase().includes(f.toLowerCase()) || f.toLowerCase().includes(cf.toLowerCase()))
    ).length;
    
    const baseScore = 3 + Math.min(functionOverlap, 2);
    
    return {
      name: comp.name,
      url: comp.url,
      country: 'Россия',
      description: comp.description,
      features: comp.features,
      pricing: comp.pricing,
      targetAudience: idea.userTypes,
      swotHtml: generateSWOTTable(
        comp.strengths,
        comp.weaknesses,
        ['Расширение рынка', 'Новые интеграции'],
        ['Конкуренция', 'Технологические изменения']
      ),
      scores: {
        functionality: Math.min(5, baseScore),
        price: baseScore > 4 ? 3 : 4,
        ux: 3,
        support: 3,
      },
    };
  });

  const indirectCompetitors = mapping.indirectCompetitors.map(comp => ({
    ...comp,
  }));

  // Build comparison table
  const compNames = directCompetitors.slice(0, 3).map(c => c.name).join(' | ');
  const comparisonTable = `
| Критерий | ${compNames} | ${idea.name || 'Продукт'} |
|---|---|---|
| Функциональность | ${directCompetitors.slice(0, 3).map(() => '⭐⭐⭐⭐').join(' | ')} | ⭐⭐⭐⭐⭐ |
| UX/UI | ${directCompetitors.slice(0, 3).map(() => '⭐⭐⭐').join(' | ')} | ⭐⭐⭐⭐⭐ |
| Поддержка РФ | ${directCompetitors.slice(0, 3).map(() => '⭐⭐⭐⭐').join(' | ')} | ⭐⭐⭐⭐⭐ |
`;

  // Build differentiation based on idea's unique functions
  const differentiationOpportunities = [
    ...idea.functions.slice(0, 2).map(f => `**${f}** — ключевой функционал продукта`),
    ...(idea.valueProposition ? [`**${idea.valueProposition}** — уникальное преимущество`] : []),
    '**Простота интерфейса** — фокус на UX, в отличие от перегруженных конкурентов',
    '**Российский рынок** — полная локализация и поддержка',
    '**Гибкость** — кастомизация под конкретные нужды бизнеса',
  ];

  let positioningRecommendation = `${idea.name || 'Продукт'} должен позиционироваться`;
  if (idea.industry) {
    positioningRecommendation += ` в отрасли "${idea.industry}"`;
  }
  positioningRecommendation += ` с ключевыми функциями: ${idea.functions.slice(0, 3).join(', ')}`;
  if (idea.valueProposition) {
    positioningRecommendation += `. Главное преимущество: ${idea.valueProposition}`;
  }
  positioningRecommendation += `\n\nНа рынке присутствуют: ${directCompetitors.map(c => c.name).join(', ')}. Дифференцируемся за счёт удобного интерфейса и уникального функционала.`;

  return {
    productName: idea.name || 'Продукт',
    industryName: idea.industry || 'Не указана',
    marketSize: mapping.marketSize,
    marketTrends: mapping.trends,
    directCompetitors,
    indirectCompetitors,
    comparisonTable,
    differentiationOpportunities: differentiationOpportunities.slice(0, 5),
    positioningRecommendation,
    contextUsed,
  };
}

function buildGenericAnalysis(idea: ExtractedIdea, contextUsed: string[]): CompetitorAnalysisResult {
  // Generic fallback when no industry matches
  const directCompetitors = [
    {
      name: 'Требуется веб-поиск',
      url: '#',
      country: '',
      description: `Для отрасли "${idea.industry || 'не указана'}" необходимо выполнить веб-поиск для определения реальных конкурентов`,
      features: idea.functions.slice(0, 3),
      pricing: 'Не определено',
      targetAudience: idea.userTypes,
      swotHtml: generateSWOTTable(
        ['Требуется анализ'],
        ['Требуется анализ'],
        ['Требуется анализ'],
        ['Требуется анализ']
      ),
      scores: { functionality: 3, price: 3, ux: 3, support: 3 },
    },
  ];

  const differentiationOpportunities = [
    ...idea.functions.slice(0, 2).map(f => `**${f}** — ключевой функционал`),
    ...(idea.valueProposition ? [`**${idea.valueProposition}** — уникальное преимущество`] : []),
    '**Простота интерфейса** — фокус на UX',
    '**Российский рынок** — локализация и поддержка',
  ];

  return {
    productName: idea.name || 'Продукт',
    industryName: idea.industry || 'Не указана',
    marketSize: idea.marketContext || 'Данные не указаны',
    marketTrends: [],
    directCompetitors,
    indirectCompetitors: [],
    comparisonTable: '',
    differentiationOpportunities: differentiationOpportunities.slice(0, 5),
    positioningRecommendation: `${idea.name || 'Продукт'} — ${idea.description || 'инновационное решение'}`,
    contextUsed,
  };
}

// ═══════════════════════════════════════════════════════════════
// FORMAT AS MARKDOWN
// ═══════════════════════════════════════════════════════════════

export function formatCompetitorAnalysisAsMarkdown(result: CompetitorAnalysisResult): string {
  const md = `## Конкурентный анализ для "${result.productName}"

### Тип продукта: ${result.industryName}

---

## 1. ПРЯМЫЕ КОНКУРЕНТЫ

${result.directCompetitors.map((c, i) => `### ${i + 1}. ${c.name} ${c.country ? `(${c.country})` : ''}

> **Сайт:** ${c.url}  
> **Описание:** ${c.description}  
> **Основные функции:** ${c.features.join(', ')}  
> **Ценовая модель:** ${c.pricing}  
> **Целевая аудитория:** ${c.targetAudience}

#### SWOT-анализ

${c.swotHtml}`).join('\n\n---\n\n')}

---

## 2. ВОЗМОЖНОСТИ ДИФФЕРЕНЦИАЦИИ

${result.differentiationOpportunities.map((d, i) => `${i + 1}. ${d}`).join('\n')}

---

## 3. РЕКОМЕНДАЦИИ ПО ПОЗИЦИОНИРОВАНИЮ

${result.positioningRecommendation}

${result.contextUsed.length > 0 ? `---\n\n*Контекст анализа: ${result.contextUsed.join(' | ')}*` : ''}
`;

  return md;
}

// ═══════════════════════════════════════════════════════════════
// FORMAT AS HTML
// ═══════════════════════════════════════════════════════════════

export function formatCompetitorAnalysisAsHTML(result: CompetitorAnalysisResult): string {
  return `
<div class="competitor-analysis">
  <style>
    .competitor-analysis { font-family: 'Inter', -apple-system, sans-serif; }
    .competitor-analysis h2 { color: #1a1a2e; font-size: 1.75rem; margin-bottom: 1rem; }
    .competitor-analysis h3 { color: #16213e; font-size: 1.25rem; margin: 1.5rem 0 0.75rem; }
  </style>

  <h2>Конкурентный анализ для "${result.productName}"</h2>
  
  <div class="product-type">${result.industryName}</div>
  
  <hr/>
  
  <h3>1. ПРЯМЫЕ КОНКУРЕНТЫ</h3>
  
  ${result.directCompetitors.map((c, i) => `
  <div class="competitor-card">
    <div class="competitor-header">
      <div class="competitor-number">${i + 1}</div>
      <div>
        <div class="competitor-name">${c.name}</div>
        <div class="competitor-country">${c.country}</div>
      </div>
    </div>
    
    <p><strong>Описание:</strong> ${c.description}</p>
    <p><strong>Функции:</strong> ${c.features.join(', ')}</p>
    <p><strong>Цены:</strong> ${c.pricing}</p>
  </div>
  `).join('')}
  
  <h3>2. ВОЗМОЖНОСТИ ДИФФЕРЕНЦИАЦИИ</h3>
  
  ${result.differentiationOpportunities.map(d => `
  <div class="opportunity-item">${d}</div>
  `).join('')}
  
  <div class="positioning-box">
    <h3>3. РЕКОМЕНДАЦИИ ПО ПОЗИЦИОНИРОВАНИЮ</h3>
    <p>${result.positioningRecommendation}</p>
  </div>
  
  ${result.contextUsed.length > 0 ? `
  <div class="context-box" style="margin-top: 20px; padding: 16px; background: #f8fafc; border-radius: 8px; font-size: 13px; color: #64748b;">
    Контекст анализа: ${result.contextUsed.join(' | ')}
  </div>` : ''}
</div>`;
}
