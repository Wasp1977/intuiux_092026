// Context-Aware Competitor Search v1.0
// Builds competitor search queries from FULL idea context (industry, functions, value prop, audience)
// NOT just from title/description like the old extractProductInfo()

import { ExtractedIdea } from './idea-extractor';
import { LLM } from './zai';
import ZAI from 'z-ai-web-dev-sdk';

// ═══════════════════════════════════════════════════════════════
// INTERFACES
// ═══════════════════════════════════════════════════════════════

export interface CompetitorContextProfile {
  // Core identification
  productName: string;
  productDescription: string;
  industry: string;
  subIndustry: string;

  // Functional context
  keyFunctions: string[];
  valueProposition: string;
  useCases: string[];

  // Market context
  targetAudience: string;
  marketContext: string;
  risks: string[];

  // Generated search intelligence
  searchStrategy: SearchQuery[];
  competitorCategories: CompetitorCategory[];
}

interface SearchQuery {
  query: string;
  language: 'ru' | 'en';
  purpose: 'direct' | 'indirect' | 'market' | 'alternative';
  priority: number; // 1 = highest
}

interface CompetitorCategory {
  name: string;
  description: string;
  searchTerms: string[];
}

export interface ContextAwareSearchResult {
  profile: CompetitorContextProfile;
  competitors: FoundCompetitor[];
  marketInsights: MarketInsight[];
  searchMetadata: {
    queriesExecuted: string[];
    totalResultsFound: number;
    analysisTimestamp: string;
  };
}

export interface FoundCompetitor {
  name: string;
  url: string;
  snippet: string;
  source: 'web_search';
  relevanceScore: number;
  category: 'direct' | 'indirect' | 'alternative' | 'incumbent';
  enriched?: {
    description: string;
    features: string[];
    pricing: string;
    strengths: string[];
    weaknesses: string[];
    swot: {
      strengths: string[];
      weaknesses: string[];
      opportunities: string[];
      threats: string[];
    };
  };
}

interface MarketInsight {
  type: 'trend' | 'barrier' | 'opportunity' | 'threat';
  text: string;
  source: string;
}

// ═══════════════════════════════════════════════════════════════
// STEP 1: BUILD CONTEXT PROFILE FROM EXTRACTED IDEA
// ═══════════════════════════════════════════════════════════════

export function buildContextProfile(idea: ExtractedIdea): CompetitorContextProfile {
  const profile: CompetitorContextProfile = {
    productName: idea.name || 'Продукт',
    productDescription: idea.description || '',
    industry: idea.industry || '',
    subIndustry: idea.subIndustry || '',
    keyFunctions: idea.functions || [],
    valueProposition: idea.valueProposition || '',
    useCases: idea.useCases || [],
    targetAudience: idea.userTypes || '',
    marketContext: idea.marketContext || '',
    risks: idea.risks || [],
    searchStrategy: [],
    competitorCategories: [],
  };

  // Generate search strategy based on context
  profile.searchStrategy = generateSearchStrategy(profile);
  profile.competitorCategories = identifyCompetitorCategories(profile);

  return profile;
}

// ═══════════════════════════════════════════════════════════════
// STEP 2: GENERATE INTELLIGENT SEARCH QUERIES
// ═══════════════════════════════════════════════════════════════

function generateSearchStrategy(profile: CompetitorContextProfile): SearchQuery[] {
  const queries: SearchQuery[] = [];
  const { productName, industry, subIndustry, keyFunctions, valueProposition, targetAudience, productDescription } = profile;

  // ── Tier 1: Industry-specific direct competitor queries (highest priority) ──
  
  // Russian market
  if (industry) {
    queries.push({
      query: `${industry} ${subIndustry} программное обеспечение сервис конкуренты Россия`,
      language: 'ru',
      purpose: 'direct',
      priority: 1,
    });
    
    queries.push({
      query: `${industry} ${productName} аналоги решения платформа`,
      language: 'ru',
      purpose: 'direct',
      priority: 1,
    });
  }

  // Function-based queries — search for products that do the same thing
  if (keyFunctions.length > 0) {
    const topFunctions = keyFunctions.slice(0, 3).join(' ');
    queries.push({
      query: `${topFunctions} сервис платформа решение`,
      language: 'ru',
      purpose: 'direct',
      priority: 1,
    });
    
    // English query for international competitors
    const topFunctionsEn = keyFunctions.slice(0, 2).join(' ');
    queries.push({
      query: `${topFunctionsEn} software SaaS platform competitors`,
      language: 'en',
      purpose: 'direct',
      priority: 2,
    });
  }

  // ── Tier 2: Value proposition and use case queries ──
  
  if (valueProposition) {
    queries.push({
      query: `${valueProposition.substring(0, 60)} решение сервис`,
      language: 'ru',
      purpose: 'direct',
      priority: 2,
    });
  }

  if (profile.useCases.length > 0) {
    queries.push({
      query: `${profile.useCases[0]} инструмент приложение`,
      language: 'ru',
      purpose: 'indirect',
      priority: 3,
    });
  }

  // ── Tier 3: International alternatives ──
  
  queries.push({
    query: `${productName || industry || productDescription.substring(0, 30)} alternatives competitors SaaS`,
    language: 'en',
    purpose: 'alternative',
    priority: 3,
  });

  queries.push({
    query: `best ${industry || keyFunctions[0] || ''} software 2024 2025 comparison`,
    language: 'en',
    purpose: 'alternative',
    priority: 3,
  });

  // ── Tier 4: Market context queries ──
  
  if (industry) {
    queries.push({
      query: `${industry} рынок тренды рост 2024 2025`,
      language: 'ru',
      purpose: 'market',
      priority: 4,
    });

    queries.push({
      query: `${industry} market size trends competition`,
      language: 'en',
      purpose: 'market',
      priority: 4,
    });
  }

  // ── Tier 5: Audience-specific queries ──
  
  if (targetAudience) {
    queries.push({
      query: `${targetAudience.split('\n')[0]} инструменты ${industry || ''} решения`,
      language: 'ru',
      purpose: 'indirect',
      priority: 3,
    });
  }

  // Deduplicate and sort by priority
  const seen = new Set<string>();
  return queries
    .filter(q => {
      const key = q.query.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return key.length > 5;
    })
    .sort((a, b) => a.priority - b.priority);
}

// ═══════════════════════════════════════════════════════════════
// STEP 3: IDENTIFY COMPETITOR CATEGORIES FROM CONTEXT
// ═══════════════════════════════════════════════════════════════

function identifyCompetitorCategories(profile: CompetitorContextProfile): CompetitorCategory[] {
  const categories: CompetitorCategory[] = [];

  // Direct competitors: same industry, same functions
  categories.push({
    name: 'Прямые конкуренты',
    description: `Решения в области "${profile.industry}" с аналогичными функциями`,
    searchTerms: [
      profile.industry,
      ...profile.keyFunctions.slice(0, 2),
      profile.productName,
    ].filter(Boolean),
  });

  // Indirect: different industry, solves similar problem
  if (profile.useCases.length > 0) {
    categories.push({
      name: 'Косвенные конкуренты',
      description: `Продукты, решающие похожие задачи: ${profile.useCases[0]}`,
      searchTerms: profile.useCases.slice(0, 2),
    });
  }

  // Incumbent: large platforms that might include similar features
  categories.push({
    name: 'Крупные платформы',
    description: 'Экосистемы, включающие аналогичный функционал',
    searchTerms: [
      ...profile.keyFunctions.slice(0, 1),
      'платформа',
      'экосистема',
    ],
  });

  // Alternatives: manual / free / open-source approaches
  categories.push({
    name: 'Альтернативные подходы',
    description: 'Бесплатные, Open Source или ручные способы решения',
    searchTerms: [
      ...profile.keyFunctions.slice(0, 1),
      'бесплатно',
      'open source',
      'альтернатива',
    ],
  });

  return categories;
}

// ═══════════════════════════════════════════════════════════════
// STEP 4: WEB SEARCH EXECUTION
// ═══════════════════════════════════════════════════════════════

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

async function executeWebSearch(query: string, numResults: number = 8): Promise<{
  title: string;
  url: string;
  snippet: string;
}[]> {
  try {
    const zai = await getZAI();
    const results = await zai.functions.invoke('web_search', {
      query,
      num: numResults,
    });

    if (Array.isArray(results)) {
      return results.map((r: any) => ({
        title: r.name || r.title || '',
        url: r.url || r.link || '',
        snippet: r.snippet || r.description || '',
      }));
    }
    return [];
  } catch (error) {
    console.error(`[ContextSearch] Web search error for "${query}":`, error);
    return [];
  }
}

// ═══════════════════════════════════════════════════════════════
// STEP 5: SCORE AND DEDUPLICATE RESULTS
// ═══════════════════════════════════════════════════════════════

function calculateRelevanceScore(
  result: { title: string; snippet: string; url: string },
  profile: CompetitorContextProfile
): number {
  let score = 0;
  const text = `${result.title} ${result.snippet}`.toLowerCase();

  // Exact product name mention
  if (profile.productName && text.includes(profile.productName.toLowerCase())) {
    score += 15;
  }

  // Industry match
  if (profile.industry && text.includes(profile.industry.toLowerCase())) {
    score += 10;
  }

  // Function matches
  for (const func of profile.keyFunctions) {
    if (func.length > 3 && text.includes(func.toLowerCase())) {
      score += 8;
    }
  }

  // Competitor signal words
  const competitorSignals = [
    'конкурент', 'аналог', 'альтернатива', 'замена', 'vs', 'сравнение',
    'competitor', 'alternative', 'vs', 'comparison', 'review'
  ];
  for (const signal of competitorSignals) {
    if (text.includes(signal)) {
      score += 5;
    }
  }

  // Product signal words
  const productSignals = [
    'сервис', 'платформа', 'программ', 'решение', 'система', 'приложение',
    'service', 'platform', 'software', 'solution', 'app', 'saas', 'tool'
  ];
  for (const signal of productSignals) {
    if (text.includes(signal)) {
      score += 3;
    }
  }

  // Penalize non-product pages
  const nonProductSignals = [
    'vacancy', 'вакансия', 'job', 'работа', 'github', 'wikipedia', 'википеди',
    'habr', 'статья', 'article', 'блог'
  ];
  for (const signal of nonProductSignals) {
    if (text.includes(signal)) {
      score -= 5;
    }
  }

  // Bonus for .ru domains (Russian market)
  if (result.url.includes('.ru')) {
    score += 3;
  }

  return Math.max(0, score);
}

function categorizeResult(
  result: { title: string; snippet: string; url: string },
  profile: CompetitorContextProfile
): FoundCompetitor['category'] {
  const text = `${result.title} ${result.snippet}`.toLowerCase();
  const url = result.url.toLowerCase();

  // Check for open-source / free alternatives
  if (text.includes('open source') || text.includes('бесплатн') || url.includes('github.com')) {
    return 'alternative';
  }

  // Check for large platforms
  const bigPlatforms = ['yandex', 'google', 'microsoft', 'vk.com', 'mail.ru', 'сбербанк', 'тинькофф'];
  if (bigPlatforms.some(p => url.includes(p) || text.includes(p))) {
    return 'incumbent';
  }

  // Direct: mentions same industry or key functions
  const hasIndustryMatch = profile.industry && text.includes(profile.industry.toLowerCase());
  const hasFunctionMatch = profile.keyFunctions.some(f => f.length > 3 && text.includes(f.toLowerCase()));

  if (hasIndustryMatch && hasFunctionMatch) {
    return 'direct';
  }

  if (hasIndustryMatch || hasFunctionMatch) {
    return 'indirect';
  }

  return 'indirect';
}

function deduplicateResults(
  results: FoundCompetitor[]
): FoundCompetitor[] {
  const seen = new Set<string>();
  const deduped: FoundCompetitor[] = [];

  for (const result of results) {
    // Normalize URL for dedup
    let normalizedUrl = result.url
      .replace(/^https?:\/\/(www\.)?/, '')
      .replace(/\/$/, '')
      .split('/')[0]
      .toLowerCase();

    // Normalize name
    const normalizedName = result.name.toLowerCase().replace(/[^a-zа-яё0-9]/g, '');

    if (!seen.has(normalizedUrl) && !seen.has(normalizedName)) {
      seen.add(normalizedUrl);
      seen.add(normalizedName);
      deduped.push(result);
    }
  }

  // Sort by relevance and take top results
  return deduped
    .sort((a, b) => b.relevanceScore - a.relevanceScore)
    .slice(0, 15);
}

// ═══════════════════════════════════════════════════════════════
// STEP 6: ENRICH COMPETITOR DATA WITH LLM
// ═══════════════════════════════════════════════════════════════

async function enrichCompetitorWithLLM(
  competitor: FoundCompetitor,
  profile: CompetitorContextProfile
): Promise<FoundCompetitor> {
  const llm = new LLM();

  const systemPrompt = `Ты — аналитик по конкурентному анализу. На основе информации о конкуренте и контексте нашего продукта, извлеки детальную информацию.

ПРАВИЛА:
1. Используй ТОЛЬКО информацию из контекста и URL
2. НЕ придумывай факты
3. Если информации недостаточно — пиши "не указано"
4. Ответь в формате JSON`;

  const userPrompt = `Наш продукт: "${profile.productName}"
Отрасль: ${profile.industry}
Ключевые функции: ${profile.keyFunctions.join(', ')}
Ценностное предложение: ${profile.valueProposition}

Конкурент: ${competitor.name}
URL: ${competitor.url}
Описание из поиска: ${competitor.snippet}

Извлеки информацию в формате:
{
  "description": "Подробное описание конкурента",
  "features": ["функция 1", "функция 2", "функция 3"],
  "pricing": "Ценовая модель",
  "strengths": ["сила 1", "сила 2", "сила 3"],
  "weaknesses": ["слабость 1", "слабость 2"],
  "swot": {
    "strengths": ["сила 1", "сила 2", "сила 3"],
    "weaknesses": ["слабость 1", "слабость 2"],
    "opportunities": ["возможность 1", "возможность 2"],
    "threats": ["угроза 1"]
  }
}

Отвечай ТОЛЬКО JSON.`;

  try {
    const response = await llm.chat({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.3,
    });

    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const enriched = JSON.parse(jsonMatch[0]);
      return {
        ...competitor,
        enriched,
      };
    }
  } catch (error) {
    console.error(`[Enrich] Error enriching ${competitor.name}:`, error);
  }

  return competitor;
}

// ═══════════════════════════════════════════════════════════════
// MAIN: CONTEXT-AWARE COMPETITOR SEARCH
// ═══════════════════════════════════════════════════════════════

export async function searchCompetitorsWithContext(
  idea: ExtractedIdea,
  options?: {
    maxCompetitors?: number;
    enrichWithLLM?: boolean;
    maxSearchQueries?: number;
  }
): Promise<ContextAwareSearchResult> {
  const {
    maxCompetitors = 8,
    enrichWithLLM = true,
    maxSearchQueries = 6,
  } = options || {};

  console.log('[ContextCompetitorSearch] Starting context-aware search...');
  console.log(`[ContextCompetitorSearch] Product: "${idea.name}"`);
  console.log(`[ContextCompetitorSearch] Industry: "${idea.industry}"`);
  console.log(`[ContextCompetitorSearch] Functions: [${idea.functions.join(', ')}]`);

  // Step 1: Build context profile
  const profile = buildContextProfile(idea);
  console.log(`[ContextCompetitorSearch] Generated ${profile.searchStrategy.length} search queries`);
  console.log(`[ContextCompetitorSearch] Categories: [${profile.competitorCategories.map(c => c.name).join(', ')}]`);

  // Step 2: Execute web searches (limit to max queries)
  const queriesToRun = profile.searchStrategy.slice(0, maxSearchQueries);
  const queriesExecuted: string[] = [];
  const allRawResults: {
    title: string;
    url: string;
    snippet: string;
    query: string;
    purpose: SearchQuery['purpose'];
  }[] = [];

  for (const queryDef of queriesToRun) {
    console.log(`[ContextCompetitorSearch] Searching: "${queryDef.query}" (${queryDef.purpose})`);
    const results = await executeWebSearch(queryDef.query, 8);
    queriesExecuted.push(queryDef.query);

    for (const result of results) {
      allRawResults.push({
        ...result,
        query: queryDef.query,
        purpose: queryDef.purpose,
      });
    }

    // Small delay between searches
    await new Promise(resolve => setTimeout(resolve, 300));
  }

  console.log(`[ContextCompetitorSearch] Total raw results: ${allRawResults.length}`);

  // Step 3: Score and categorize
  const scoredResults: FoundCompetitor[] = allRawResults.map(result => ({
    name: result.title,
    url: result.url,
    snippet: result.snippet,
    source: 'web_search' as const,
    relevanceScore: calculateRelevanceScore(result, profile),
    category: categorizeResult(result, profile),
  }));

  // Step 4: Deduplicate and filter
  const uniqueResults = deduplicateResults(scoredResults);
  console.log(`[ContextCompetitorSearch] Unique results: ${uniqueResults.length}`);

  // Step 5: Take top N and optionally enrich
  const topCompetitors = uniqueResults.slice(0, maxCompetitors);
  
  let enrichedCompetitors = topCompetitors;
  if (enrichWithLLM) {
    console.log(`[ContextCompetitorSearch] Enriching ${topCompetitors.length} competitors with LLM...`);
    const enrichmentPromises = topCompetitors.map(comp =>
      enrichCompetitorWithLLM(comp, profile)
    );
    enrichedCompetitors = await Promise.all(enrichmentPromises);
  }

  // Step 6: Extract market insights
  const marketInsights: MarketInsight[] = [];
  const marketResults = allRawResults.filter(r => r.purpose === 'market');
  for (const mr of marketResults.slice(0, 5)) {
    if (mr.snippet.length > 20) {
      marketInsights.push({
        type: 'trend',
        text: mr.snippet.substring(0, 150),
        source: mr.url,
      });
    }
  }

  return {
    profile,
    competitors: enrichedCompetitors,
    marketInsights,
    searchMetadata: {
      queriesExecuted,
      totalResultsFound: allRawResults.length,
      analysisTimestamp: new Date().toISOString(),
    },
  };
}

// ═══════════════════════════════════════════════════════════════
// FORMAT AS HTML (for pipeline integration)
// ═══════════════════════════════════════════════════════════════

export function formatContextSearchAsHTML(result: ContextAwareSearchResult): string {
  const { profile, competitors, marketInsights, searchMetadata } = result;

  // Group competitors by category
  const directCompetitors = competitors.filter(c => c.category === 'direct');
  const indirectCompetitors = competitors.filter(c => c.category === 'indirect' || c.category === 'incumbent');
  const alternatives = competitors.filter(c => c.category === 'alternative');

  const competitorCard = (comp: typeof competitors[0], index: number) => {
    const enriched = comp.enriched;
    const swot = enriched?.swot || {
      strengths: enriched?.strengths || [],
      weaknesses: enriched?.weaknesses || [],
      opportunities: [],
      threats: [],
    };

    const categoryLabel: Record<string, string> = {
      direct: 'Прямой конкурент',
      indirect: 'Косвенный конкурент',
      incumbent: 'Крупная платформа',
      alternative: 'Альтернатива',
    };
    const categoryColor: Record<string, string> = {
      direct: '#3b82f6',
      indirect: '#8b5cf6',
      incumbent: '#f59e0b',
      alternative: '#6b7280',
    };

    return `
<div style="margin-bottom: 24px; border: 1px solid #e5e7eb; border-radius: 12px; overflow: hidden; background: white;">
  <div style="background: linear-gradient(135deg, ${categoryColor[comp.category]} 0%, ${categoryColor[comp.category]}dd 100%); color: white; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
    <div>
      <div style="font-size: 11px; opacity: 0.8; text-transform: uppercase; letter-spacing: 0.5px;">${index + 1}. ${categoryLabel[comp.category] || comp.category}</div>
      <h3 style="margin: 4px 0 0 0; font-size: 18px; font-weight: 600;">${comp.name}</h3>
    </div>
    <div style="background: rgba(255,255,255,0.2); padding: 4px 10px; border-radius: 20px; font-size: 12px;">
      Релевантность: ${comp.relevanceScore}
    </div>
  </div>
  ${comp.url ? `<a href="${comp.url}" style="display: block; padding: 8px 20px; background: #f8fafc; color: #3b82f6; text-decoration: none; font-size: 13px; border-bottom: 1px solid #e5e7eb;">${comp.url}</a>` : ''}
  <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
    <tr style="background: #f8fafc;">
      <td style="padding: 12px 20px; font-weight: 600; width: 140px; color: #64748b;">Описание</td>
      <td style="padding: 12px 20px;">${enriched?.description || comp.snippet || 'Не указано'}</td>
    </tr>
    ${enriched?.pricing ? `
    <tr>
      <td style="padding: 12px 20px; font-weight: 600; color: #64748b;">Цены</td>
      <td style="padding: 12px 20px;">${enriched.pricing}</td>
    </tr>` : ''}
    ${enriched?.features?.length ? `
    <tr style="background: #f8fafc;">
      <td style="padding: 12px 20px; font-weight: 600; color: #64748b; vertical-align: top;">Функции</td>
      <td style="padding: 12px 20px;">
        ${enriched.features.map(f => `<span style="display: inline-block; background: #e0f2fe; color: #0369a1; padding: 4px 10px; border-radius: 999px; font-size: 12px; margin: 2px;">${f}</span>`).join(' ')}
      </td>
    </tr>` : ''}
  </table>
  <table style="width: 100%; border-collapse: collapse; font-size: 14px; border-top: 1px solid #e5e7eb;">
    <thead>
      <tr>
        <th style="padding: 12px 16px; background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; width: 50%; text-align: left;">Сильные стороны</th>
        <th style="padding: 12px 16px; background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; width: 50%; text-align: left;">Слабые стороны</th>
      </tr>
    </thead>
    <tbody>
      <tr style="vertical-align: top;">
        <td style="padding: 16px; border: 1px solid #e5e7eb; background: #f0fdf4;">
          <ul style="margin: 0; padding-left: 20px; list-style-type: disc;">
            ${(swot.strengths.length > 0 ? swot.strengths : ['Данных недостаточно']).map(s => `<li style="color: #166534; margin-bottom: 6px;"><strong>${s}</strong></li>`).join('\n            ')}
          </ul>
        </td>
        <td style="padding: 16px; border: 1px solid #e5e7eb;">
          <ul style="margin: 0; padding-left: 20px; list-style-type: disc;">
            ${(swot.weaknesses.length > 0 ? swot.weaknesses : ['Данных недостаточно']).map(w => `<li style="color: #991b1b; margin-bottom: 6px;">${w}</li>`).join('\n            ')}
          </ul>
        </td>
      </tr>
      <tr>
        <th style="padding: 12px 16px; background: #eff6ff; color: #1e40af; border: 1px solid #bfdbfe; text-align: left;">Возможности</th>
        <th style="padding: 12px 16px; background: #fefce8; color: #854d0e; border: 1px solid #fef08a; text-align: left;">Угрозы</th>
      </tr>
      <tr style="vertical-align: top;">
        <td style="padding: 16px; border: 1px solid #e5e7eb; background: #f8fafc;">
          <ul style="margin: 0; padding-left: 20px; list-style-type: disc;">
            ${(swot.opportunities.length > 0 ? swot.opportunities : ['Требуется анализ']).map(o => `<li style="color: #1e40af; margin-bottom: 6px;">${o}</li>`).join('\n            ')}
          </ul>
        </td>
        <td style="padding: 16px; border: 1px solid #e5e7eb; background: #fffbeb;">
          <ul style="margin: 0; padding-left: 20px; list-style-type: disc;">
            ${(swot.threats.length > 0 ? swot.threats : ['Требуется анализ']).map(t => `<li style="color: #854d0e; margin-bottom: 6px;">${t}</li>`).join('\n            ')}
          </ul>
        </td>
      </tr>
    </tbody>
  </table>
</div>`;
  };

  return `
<div style="font-family: system-ui, -apple-system, sans-serif; max-width: 100%; color: #1f2937;">
  <!-- Header -->
  <div style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); color: white; padding: 28px; border-radius: 16px; margin-bottom: 28px;">
    <h1 style="margin: 0 0 8px 0; font-size: 24px;">Конкурентный анализ</h1>
    <h2 style="margin: 0 0 16px 0; font-size: 20px; font-weight: 400; opacity: 0.9;">${profile.productName}</h2>
    <div style="display: flex; gap: 20px; flex-wrap: wrap;">
      ${profile.industry ? `<div style="background: rgba(255,255,255,0.1); padding: 8px 14px; border-radius: 8px;">
        <span style="opacity: 0.7; font-size: 12px;">Отрасль</span><br/>
        <span style="font-weight: 600; font-size: 14px;">${profile.industry}</span>
      </div>` : ''}
      ${profile.targetAudience ? `<div style="background: rgba(255,255,255,0.1); padding: 8px 14px; border-radius: 8px;">
        <span style="opacity: 0.7; font-size: 12px;">Целевая аудитория</span><br/>
        <span style="font-weight: 600; font-size: 14px;">${profile.targetAudience.split('\n')[0]}</span>
      </div>` : ''}
      <div style="background: rgba(255,255,255,0.1); padding: 8px 14px; border-radius: 8px;">
        <span style="opacity: 0.7; font-size: 12px;">Конкурентов найдено</span><br/>
        <span style="font-weight: 600; font-size: 14px;">${competitors.length}</span>
      </div>
      <div style="background: rgba(255,255,255,0.1); padding: 8px 14px; border-radius: 8px;">
        <span style="opacity: 0.7; font-size: 12px;">Поисковых запросов</span><br/>
        <span style="font-weight: 600; font-size: 14px;">${searchMetadata.queriesExecuted.length}</span>
      </div>
      <div style="background: rgba(255,255,255,0.1); padding: 8px 14px; border-radius: 8px;">
        <span style="opacity: 0.7; font-size: 12px;">Источник</span><br/>
        <span style="font-weight: 600; font-size: 14px;">Контекстный веб-поиск</span>
      </div>
    </div>
  </div>

  ${profile.keyFunctions.length > 0 ? `
  <!-- Search Context -->
  <div style="background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 12px; padding: 20px; margin-bottom: 24px;">
    <h3 style="margin: 0 0 12px 0; font-size: 16px; color: #0369a1;">Контекст поиска</h3>
    <div style="display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 8px;">
      ${profile.keyFunctions.map(f => `<span style="background: #e0f2fe; color: #0369a1; padding: 4px 12px; border-radius: 999px; font-size: 13px;">${f}</span>`).join(' ')}
    </div>
    ${profile.valueProposition ? `<p style="margin: 8px 0 0 0; font-size: 13px; color: #64748b;">Ценность: ${profile.valueProposition}</p>` : ''}
  </div>` : ''}

  ${profile.searchStrategy.length > 0 ? `
  <!-- Search Queries Used -->
  <details style="margin-bottom: 24px; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
    <summary style="padding: 12px 16px; background: #f8fafc; cursor: pointer; font-weight: 600; font-size: 14px;">Поисковые запросы (${searchMetadata.queriesExecuted.length})</summary>
    <div style="padding: 12px 16px; font-size: 13px;">
      ${searchMetadata.queriesExecuted.map((q, i) => `<div style="padding: 6px 0; border-bottom: 1px solid #f1f5f9;"><span style="color: #64748b;">${i + 1}.</span> ${q}</div>`).join('')}
    </div>
  </details>` : ''}

  <!-- Direct Competitors -->
  ${directCompetitors.length > 0 ? `
  <h2 style="font-size: 18px; color: #1e293b; border-bottom: 2px solid #3b82f6; padding-bottom: 8px; margin: 0 0 20px 0;">Прямые конкуренты (${directCompetitors.length})</h2>
  ${directCompetitors.map((c, i) => competitorCard(c, i)).join('\n')}
  ` : ''}

  <!-- Indirect Competitors -->
  ${indirectCompetitors.length > 0 ? `
  <h2 style="font-size: 18px; color: #1e293b; border-bottom: 2px solid #8b5cf6; padding-bottom: 8px; margin: 28px 0 20px 0;">Косвенные конкуренты и крупные платформы (${indirectCompetitors.length})</h2>
  ${indirectCompetitors.map((c, i) => competitorCard(c, directCompetitors.length + i)).join('\n')}
  ` : ''}

  <!-- Alternatives -->
  ${alternatives.length > 0 ? `
  <h2 style="font-size: 18px; color: #1e293b; border-bottom: 2px solid #6b7280; padding-bottom: 8px; margin: 28px 0 20px 0;">Альтернативы (${alternatives.length})</h2>
  ${alternatives.map((c, i) => competitorCard(c, directCompetitors.length + indirectCompetitors.length + i)).join('\n')}
  ` : ''}

  ${competitors.length === 0 ? `
  <div style="background: #fef3c7; border: 1px solid #fbbf24; border-radius: 12px; padding: 20px; text-align: center;">
    <p style="margin: 0; color: #92400e;">Конкуренты не найдены по контексту идеи. Попробуйте уточнить описание продукта.</p>
  </div>` : ''}

  <!-- Market Insights -->
  ${marketInsights.length > 0 ? `
  <h2 style="font-size: 18px; color: #1e293b; border-bottom: 2px solid #8b5cf6; padding-bottom: 8px; margin: 28px 0 20px 0;">Рыночный контекст</h2>
  <div style="background: #f8fafc; border-left: 4px solid #8b5cf6; padding: 20px 24px; border-radius: 0 12px 12px 0;">
    <ul style="margin: 0; padding-left: 20px;">
      ${marketInsights.map(m => `<li style="margin-bottom: 8px; font-size: 14px;">${m.text} <span style="color: #9ca3af; font-size: 12px;">(${m.source})</span></li>`).join('\n      ')}
    </ul>
  </div>` : ''}

  <!-- Differentiation Recommendations -->
  <div style="background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%); color: white; padding: 24px; border-radius: 12px; margin-top: 28px;">
    <h3 style="margin: 0 0 12px 0; font-size: 18px;">Возможности дифференциации</h3>
    <ul style="margin: 0; padding-left: 20px;">
      ${profile.keyFunctions.slice(0, 3).map(f => `<li style="margin-bottom: 6px;"><strong>${f}</strong> — ключевой функционал продукта</li>`).join('\n      ')}
      ${profile.valueProposition ? `<li style="margin-bottom: 6px;"><strong>${profile.valueProposition.substring(0, 80)}</strong> — уникальное ценностное предложение</li>` : ''}
      <li style="margin-bottom: 6px;"><strong>Удобство интерфейса</strong> — фокус на UX на основе пользовательских исследований</li>
      <li style="margin-bottom: 6px;"><strong>Локализация</strong> — адаптация под российский рынок и регулирование</li>
    </ul>
  </div>

  <!-- Metadata -->
  <div style="margin-top: 28px; padding: 16px; background: #f8fafc; border-radius: 8px; font-size: 12px; color: #6b7280;">
    Анализ выполнен на основе контекста идеи с использованием веб-поиска | ${new Date().toLocaleDateString('ru-RU')} | Запросов: ${searchMetadata.queriesExecuted.length} | Результатов: ${searchMetadata.totalResultsFound}
  </div>
</div>`;
}

// ═══════════════════════════════════════════════════════════════
// FORMAT AS MARKDOWN
// ═══════════════════════════════════════════════════════════════

export function formatContextSearchAsMarkdown(result: ContextAwareSearchResult): string {
  const { profile, competitors, marketInsights, searchMetadata } = result;

  const directCompetitors = competitors.filter(c => c.category === 'direct');
  const indirectCompetitors = competitors.filter(c => c.category === 'indirect' || c.category === 'incumbent');
  const alternatives = competitors.filter(c => c.category === 'alternative');

  let md = `# Конкурентный анализ: ${profile.productName}

## Контекст поиска

- **Отрасль:** ${profile.industry || 'Не определена'}
- **Целевая аудитория:** ${profile.targetAudience || 'Не указана'}
- **Ключевые функции:** ${profile.keyFunctions.join(', ') || 'Не указаны'}
- **Ценностное предложение:** ${profile.valueProposition || 'Не указано'}
- **Конкурентов найдено:** ${competitors.length}
- **Поисковых запросов:** ${searchMetadata.queriesExecuted.length}

---

## Прямые конкуренты (${directCompetitors.length})

${directCompetitors.map((c, i) => {
  const e = c.enriched;
  const swot = e?.swot;
  return `### ${i + 1}. ${c.name}

${c.url ? `> URL: ${c.url}` : ''}

**Описание:** ${e?.description || c.snippet || 'Не указано'}
**Цены:** ${e?.pricing || 'Не указано'}
**Функции:** ${e?.features?.join(', ') || 'Не указаны'}

${swot ? `| Сильные стороны | Слабые стороны |
|---|---|
| ${swot.strengths.join('<br>')} | ${swot.weaknesses.join('<br>')} |

| Возможности | Угрозы |
|---|---|
| ${swot.opportunities.join('<br>')} | ${swot.threats.join('<br>')} |` : ''}
`;
}).join('\n---\n\n')}

---

## Косвенные конкуренты (${indirectCompetitors.length})

${indirectCompetitors.map((c, i) => `### ${i + 1}. ${c.name}
${c.url ? `> URL: ${c.url}` : ''}
**Описание:** ${c.enriched?.description || c.snippet || 'Не указано'}`).join('\n\n')}

---

## Альтернативы (${alternatives.length})

${alternatives.map((c, i) => `- **${c.name}** — ${c.snippet || c.url}`).join('\n')}

---

## Возможности дифференциации

${profile.keyFunctions.slice(0, 3).map(f => `- **${f}** — ключевой функционал`).join('\n')}
${profile.valueProposition ? `- **${profile.valueProposition}** — уникальное ценностное предложение` : ''}
- **UX/UI** — фокус на удобстве интерфейса
- **Локализация** — адаптация под российский рынок

`;

  if (marketInsights.length > 0) {
    md += `---\n\n## Рыночный контекст\n\n${marketInsights.map(m => `- ${m.text}`).join('\n')}\n`;
  }

  return md;
}
