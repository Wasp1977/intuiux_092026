import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { LLM } from '@/lib/zai';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, correction } = body

    if (!sessionId) {
      return NextResponse.json({ success: false, error: 'Missing sessionId' }, { status: 400 });
    }

    const ideaStage = await db.pipelineStage.findUnique({
      where: { sessionId_stageNumber: { sessionId, stageNumber: 1 } }
    });
    const prototypeStage = await db.pipelineStage.findUnique({
      where: { sessionId_stageNumber: { sessionId, stageNumber: 6 } }
    });

    if (!ideaStage?.outputData || !prototypeStage?.outputData) {
      return NextResponse.json({ success: false, error: 'Previous stages not completed' }, { status: 400 });
    }

    const ideaData = JSON.parse(ideaStage.outputData);
    const prototypeData = prototypeStage?.outputData ? JSON.parse(prototypeStage.outputData) : null;

    await db.pipelineStage.update({
      where: { sessionId_stageNumber: { sessionId, stageNumber: 7 } },
      data: {
        status: 'processing',
        startedAt: new Date(),
        inputData: JSON.stringify({ ideaData, prototypeData, correction })
      }
    });

    const systemPrompt = `Ты — Senior UX Researcher. Гайдлайн для юзабилити-тестирования прототипа. Русский язык. КОНКРЕТИКА для конкретного продукта. Структура: 1. ПОДГОТОВКА (чек-лист) 2. СТРУКТУРА СЕССИИ (таблица: время/этап/действие/результат) 3. СКРИПТ МОДЕРАТОРА (полный текст) 4. ЗАДАЧИ (5 конкретных задач с критериями успеха) 5. ПОСТ-ТЕСТ ИНТЕРВЬЮ (SUS + 5 вопросов) 6. ЧЕК-ЛИСТ НАБЛЮДАТЕЛЯ 7. ШАБЛОН ПРОТОКОЛА.`;

    const userPrompt = correction
      ? `Идея продукта:\n${JSON.stringify(ideaData, null, 2)}\n\nПрототип:\n${JSON.stringify(prototypeData, null, 2)}\n\nКорректировка:\n${correction}`
      : `Создай руководство по тестированию для:\n\n${JSON.stringify(ideaData, null, 2)}\n\nПрототип:\n${JSON.stringify(prototypeData, null, 2)}`;

    const llm = new LLM();
    const response = await llm.chat({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      temperature: 0.7
    });

    let guidelinesData
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        guidelinesData = JSON.parse(jsonMatch[0])
      } else {
        throw new Error('No JSON found')
      }
    } catch {
      guidelinesData = {
        overview: { purpose: '', scope: '', targetUsers: '', duration: '' },
        preparation: { checklist: [], equipment: [], environment: '' },
        tasks: [],
        questions: { preTest: [], duringTest: [], postTest: [], satisfactionScale: { name: '', questions: [] } },
        moderatorGuide: { introduction: '', instructions: '', thingsToAvoid: [], thinkAloud: '' },
        dataCollection: { methods: [], metrics: [], tools: [] },
        analysis: { framework: '', severityScale: { critical: '', major: '', minor: '' }, reporting: '' }
      }
    }

    await db.pipelineStage.update({
      where: { sessionId_stageNumber: { sessionId, stageNumber: 8 } },
      data: {
        status: 'completed',
        outputData: JSON.stringify(guidelinesData),
        completedAt: new Date()
      }
    })

    return NextResponse.json({ success: true, data: guidelinesData })

  } catch (error) {
    console.error('Guidelines generation error:', error)
    
    const body = await request.clone().json().catch(() => ({}))
    if (body.sessionId) {
      await db.pipelineStage.update({
        where: { sessionId_stageNumber: { sessionId: body.sessionId, stageNumber: 8 } },
        data: {
          status: 'error',
          errorMessage: error instanceof Error ? error.message : 'Unknown error'
        }
      }).catch(console.error)
    }

    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Failed to create guidelines' 
    }, { status: 500 })
  }
}
