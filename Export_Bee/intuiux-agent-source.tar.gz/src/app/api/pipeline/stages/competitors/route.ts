import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { searchCompetitorsWithContext, formatContextSearchAsHTML, formatContextSearchAsMarkdown } from '@/lib/context-aware-competitor-search';
import { extractIdeaFromText, type ExtractedIdea } from '@/lib/idea-extractor';

// ═══════════════════════════════════════════════════════════════
// Pipeline Competitors Stage - CONTEXT-AWARE v3.0
// Uses full ExtractedIdea context to build intelligent competitor search
// ═══════════════════════════════════════════════════════════════

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, correction } = body;

    if (!sessionId) {
      return NextResponse.json({ 
        success: false, 
        error: 'Missing sessionId' 
      }, { status: 400 });
    }

    // Get idea stage data
    const ideaStage = await db.pipelineStage.findFirst({
      where: { sessionId, stageName: 'idea' }
    });
    const competitorsStage = await db.pipelineStage.findFirst({
      where: { sessionId, stageName: 'competitors' }
    });

    if (!ideaStage?.outputData) {
      return NextResponse.json({ 
        success: false, 
        error: 'Idea stage not completed' 
      }, { status: 400 });
    }

    if (!competitorsStage) {
      return NextResponse.json({ 
        success: false, 
        error: 'Competitors stage not found in pipeline' 
      }, { status: 400 });
    }

    // Update status
    await db.pipelineStage.update({
      where: { id: competitorsStage.id },
      data: {
        status: 'processing',
        startedAt: new Date(),
        inputData: JSON.stringify({ correction })
      }
    });

    // ═══════════════════════════════════════════════════
    // STEP 1: Build full ExtractedIdea from source text
    // ═══════════════════════════════════════════════════
    
    let extractedIdea: ExtractedIdea;
    
    // Try to get source text from inputData first (original transcription)
    let sourceText = '';
    try {
      const ideaInput = ideaStage.inputData ? JSON.parse(ideaStage.inputData) : {};
      sourceText = ideaInput.inputText || '';
    } catch (e) {
      console.log('[Competitors] Could not parse idea input data');
    }

    if (sourceText) {
      // Extract structured idea from the original transcription text
      console.log(`[Competitors v3.0] Extracting idea from source text (${sourceText.length} chars)`);
      extractedIdea = extractIdeaFromText(sourceText);
    } else {
      // Try to reconstruct from output data
      const ideaData = JSON.parse(ideaStage.outputData);
      console.log(`[Competitors v3.0] Reconstructing idea from stage output`);
      extractedIdea = {
        name: ideaData.title || ideaData.name || '',
        description: ideaData.description || '',
        industry: ideaData.industry || '',
        industryContext: ideaData.marketContext || '',
        subIndustry: ideaData.subIndustry || '',
        marketContext: ideaData.marketContext || '',
        functions: ideaData.functions || ideaData.keyFunctions || [],
        useCases: ideaData.useCases || [],
        userTypes: ideaData.targetAudience || ideaData.userTypes || '',
        valueProposition: ideaData.valueProposition || '',
        risks: ideaData.risks || [],
        difficulties: ideaData.difficulties || [],
        hypotheses: [],
        userStories: [],
        jtbd: [],
        functionalRequirements: ideaData.functionalRequirements || [],
        poInsights: [],
        mvpScope: ideaData.mvpScope || [],
        extractionLog: ['[v3.0] Reconstructed from pipeline stage output'],
      };
    }

    // Apply correction if provided
    if (correction) {
      console.log(`[Competitors v3.0] Applying user correction`);
      if (correction.trim().length > 0) {
        extractedIdea.description = `${extractedIdea.description}\n\nКонтекст от пользователя: ${correction}`;
      }
      
      // Try to extract more specific info from correction
      const industryMatch = correction.match(/(?:отрасль|сфера|рынок)[а-яё]*\s*[—–:]?\s*([а-яёa-z\s]{3,40})/i);
      if (industryMatch) {
        extractedIdea.industry = industryMatch[1].trim();
      }
    }

    // Log the context being used for search
    console.log(`[Competitors v3.0] CONTEXT-AWARE SEARCH:
      - Name: "${extractedIdea.name}"
      - Industry: "${extractedIdea.industry}"
      - SubIndustry: "${extractedIdea.subIndustry}"
      - Functions: [${extractedIdea.functions.join(', ')}]
      - ValueProp: "${extractedIdea.valueProposition?.substring(0, 50) || 'N/A'}..."
      - Audience: "${extractedIdea.userTypes?.substring(0, 50) || 'N/A'}..."
      - UseCases: [${extractedIdea.useCases.length}]
    `);

    // ═══════════════════════════════════════════════════
    // STEP 2: Run context-aware competitor search
    // ═══════════════════════════════════════════════════
    
    const searchResult = await searchCompetitorsWithContext(extractedIdea, {
      maxCompetitors: 10,
      enrichWithLLM: true,
      maxSearchQueries: 7,
    });

    console.log(`[Competitors v3.0] Found ${searchResult.competitors.length} competitors`);
    console.log(`[Competitors v3.0] Categories: ${JSON.stringify(
      searchResult.competitors.reduce((acc, c) => {
        acc[c.category] = (acc[c.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    )}`);

    // ═══════════════════════════════════════════════════
    // STEP 3: Format output for pipeline
    // ═══════════════════════════════════════════════════

    const htmlOutput = formatContextSearchAsHTML(searchResult);
    const markdownOutput = formatContextSearchAsMarkdown(searchResult);

    // Group competitors by category
    const directCompetitors = searchResult.competitors
      .filter(c => c.category === 'direct')
      .map(c => ({
        name: c.name,
        url: c.url,
        country: '',
        description: c.enriched?.description || c.snippet || '',
        features: c.enriched?.features || [],
        pricing: c.enriched?.pricing || 'Не указано',
        targetAudience: '',
        swotHtml: c.enriched?.swot ? formatSwotAsHtml(c.enriched.swot) : '',
        strengths: c.enriched?.swot?.strengths || [],
        weaknesses: c.enriched?.swot?.weaknesses || [],
        opportunities: c.enriched?.swot?.opportunities || [],
        threats: c.enriched?.swot?.threats || [],
        marketPosition: '',
        countryOrigin: '',
        relevanceScore: c.relevanceScore,
      }));

    const indirectCompetitors = searchResult.competitors
      .filter(c => c.category === 'indirect' || c.category === 'incumbent')
      .map(c => ({
        name: c.name,
        description: c.enriched?.description || c.snippet || '',
        approach: '',
        overlap: '',
        differentiation: '',
      }));

    const competitorsData = {
      productName: searchResult.profile.productName,
      industryName: searchResult.profile.industry || 'Не определена',
      marketSize: searchResult.profile.marketContext || 'Не указано',
      marketTrends: searchResult.marketInsights.map(m => m.text),
      directCompetitors,
      indirectCompetitors,
      searchStrategy: searchResult.profile.searchStrategy.map(q => q.query),
      competitorCategories: searchResult.profile.competitorCategories.map(c => ({
        name: c.name,
        description: c.description,
        searchTerms: c.searchTerms,
      })),
      comparisonTable: generateComparisonTable(searchResult),
      differentiationStrategy: searchResult.profile.valueProposition 
        ? `Ключевое преимущество: ${searchResult.profile.valueProposition}`
        : '',
      competitiveAdvantages: searchResult.profile.keyFunctions.map(f => ({
        advantage: f,
        type: 'functional',
      })),
      positioningRecommendation: generatePositioningRecommendation(searchResult),
      markdownOutput,
      htmlOutput,
      searchPerformed: true,
      contextAware: true,
      searchMetadata: searchResult.searchMetadata,
      searchDate: new Date().toISOString(),
    };

    // ═══════════════════════════════════════════════════
    // STEP 4: Save result to pipeline
    // ═══════════════════════════════════════════════════
    
    await db.pipelineStage.update({
      where: { id: competitorsStage.id },
      data: {
        status: 'completed',
        outputData: JSON.stringify(competitorsData),
        completedAt: new Date()
      }
    });

    return NextResponse.json({ success: true, data: competitorsData });

  } catch (error) {
    console.error('Competitors analysis error:', error);
    
    const body = await request.clone().json().catch(() => ({}));
    if (body.sessionId) {
      const competitorsStage = await db.pipelineStage.findFirst({
        where: { sessionId: body.sessionId, stageName: 'competitors' }
      });
      if (competitorsStage) {
        await db.pipelineStage.update({
          where: { id: competitorsStage.id },
          data: {
            status: 'error',
            errorMessage: error instanceof Error ? error.message : 'Unknown error'
          }
        });
      }
    }

    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Failed to analyze competitors' 
    }, { status: 500 });
  }
}

// ═══════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

function formatSwotAsHtml(swot: {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
}): string {
  return `
| Сильные стороны | Слабые стороны |
|---|---|
| ${swot.strengths.map(s => `✓ ${s}`).join('<br>')} | ${swot.weaknesses.map(w => `✗ ${w}`).join('<br>')} |

| Возможности | Угрозы |
|---|---|
| ${swot.opportunities.map(o => `→ ${o}`).join('<br>')} | ${swot.threats.map(t => `⚠ ${t}`).join('<br>')} |
`;
}

function generateComparisonTable(result: Awaited<ReturnType<typeof searchCompetitorsWithContext>>): string {
  const directComps = result.competitors.filter(c => c.category === 'direct').slice(0, 3);
  if (directComps.length === 0) return '';
  
  const headers = directComps.map(c => c.name).join(' | ');
  
  return `
| Критерий | ${headers} | ${result.profile.productName} |
|---|---|---|
| Функциональность | ${directComps.map(() => '⭐⭐⭐⭐').join(' | ')} | ⭐⭐⭐⭐⭐ |
| UX/UI | ${directComps.map(() => '⭐⭐⭐').join(' | ')} | ⭐⭐⭐⭐⭐ |
| Поддержка РФ | ${directComps.map(() => '⭐⭐⭐').join(' | ')} | ⭐⭐⭐⭐⭐ |
`;
}

function generatePositioningRecommendation(result: Awaited<ReturnType<typeof searchCompetitorsWithContext>>): string {
  const { profile } = result;
  
  let rec = `${profile.productName} должен позиционироваться`;
  if (profile.industry) {
    rec += ` в отрасли "${profile.industry}"`;
  }
  if (profile.keyFunctions.length > 0) {
    rec += ` с ключевыми функциями: ${profile.keyFunctions.slice(0, 3).join(', ')}`;
  }
  if (profile.valueProposition) {
    rec += `. Главное преимущество: ${profile.valueProposition}`;
  }
  
  // Add context-aware differentiation based on found competitors
  const competitorNames = result.competitors.slice(0, 5).map(c => c.name).join(', ');
  if (competitorNames) {
    rec += `\n\nОсновные конкуренты на рынке: ${competitorNames}`;
    rec += `\nДифференциация: фокус на удобстве интерфейса, локализации и уникальных функциях, которых нет у конкурентов.`;
  }
  
  return rec;
}
