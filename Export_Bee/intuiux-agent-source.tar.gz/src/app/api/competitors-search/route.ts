// Competitors Search API v3.0 - CONTEXT-AWARE COMPETITOR SEARCH
// Now accepts full ExtractedIdea context to build intelligent search queries
// Falls back to raw text parsing if ExtractedIdea not provided

import { NextRequest, NextResponse } from 'next/server';
import { 
  searchCompetitorsWithContext, 
  formatContextSearchAsHTML,
  type ContextAwareSearchResult,
} from '@/lib/context-aware-competitor-search';
import { extractIdeaFromText, type ExtractedIdea } from '@/lib/idea-extractor';

// ═══════════════════════════════════════════════════════════════
// MAIN API HANDLER
// ═══════════════════════════════════════════════════════════════

export async function POST(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    const body = await request.json();
    const { idea, ideaData, correction, enrichWithLLM } = body;

    // Accept either raw text ('idea') or pre-extracted ExtractedIdea ('ideaData')
    if (!idea && !ideaData) {
      return NextResponse.json({ 
        success: false, 
        error: 'Either "idea" (text) or "ideaData" (ExtractedIdea) is required' 
      }, { status: 400 });
    }

    console.log('[CompetitorsSearch v3.0] Starting CONTEXT-AWARE search...');

    // Step 1: Build ExtractedIdea from available data
    let extractedIdea: ExtractedIdea;
    
    if (ideaData && ideaData.name) {
      // Pre-extracted idea data passed directly
      console.log(`[CompetitorsSearch v3.0] Using pre-extracted idea: "${ideaData.name}"`);
      extractedIdea = ideaData as ExtractedIdea;
    } else if (typeof idea === 'string') {
      // Raw text — extract idea from it
      console.log(`[CompetitorsSearch v3.0] Extracting idea from text (${idea.length} chars)`);
      extractedIdea = extractIdeaFromText(idea);
    } else {
      return NextResponse.json({ 
        success: false, 
        error: 'Invalid input format' 
      }, { status: 400 });
    }

    // Apply user correction if provided
    if (correction) {
      console.log(`[CompetitorsSearch v3.0] Applying user correction`);
      extractedIdea = applyCorrection(extractedIdea, correction);
    }

    console.log(`[CompetitorsSearch v3.0] Context:
      - Name: "${extractedIdea.name}"
      - Industry: "${extractedIdea.industry}"
      - SubIndustry: "${extractedIdea.subIndustry}"
      - Functions: [${extractedIdea.functions.join(', ')}]
      - ValueProp: "${extractedIdea.valueProposition?.substring(0, 50)}..."
      - Audience: "${extractedIdea.userTypes?.substring(0, 50)}..."
    `);

    // Step 2: Run context-aware search
    const searchResult = await searchCompetitorsWithContext(extractedIdea, {
      maxCompetitors: 10,
      enrichWithLLM: enrichWithLLM !== false, // default true
      maxSearchQueries: 7,
    });

    console.log(`[CompetitorsSearch v3.0] Found ${searchResult.competitors.length} competitors`);
    console.log(`[CompetitorsSearch v3.0] Categories: ${JSON.stringify(
      searchResult.competitors.reduce((acc, c) => {
        acc[c.category] = (acc[c.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    )}`);

    // Step 3: Format output as HTML
    const analysisHtml = formatContextSearchAsHTML(searchResult);

    // Also generate markdown for data storage
    const { formatContextSearchAsMarkdown } = await import('@/lib/context-aware-competitor-search');
    const markdownOutput = formatContextSearchAsMarkdown(searchResult);

    console.log(`[CompetitorsSearch v3.0] Completed in ${Date.now() - startTime}ms`);
    
    return NextResponse.json({ 
      success: true, 
      analysis: analysisHtml,
      markdownOutput,
      competitorsCount: searchResult.competitors.length,
      searchMetadata: searchResult.searchMetadata,
      profile: {
        productName: searchResult.profile.productName,
        industry: searchResult.profile.industry,
        searchQueriesCount: searchResult.profile.searchStrategy.length,
        competitorCategories: searchResult.profile.competitorCategories.map(c => c.name),
      },
      searchPerformed: true,
      contextAware: true,
      searchDate: new Date().toISOString(),
      elapsed: Date.now() - startTime,
    });

  } catch (error) {
    console.error('[CompetitorsSearch v3.0] Error:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Failed to analyze competitors' 
    }, { status: 500 });
  }
}

// ═══════════════════════════════════════════════════════════════
// APPLY USER CORRECTION TO EXTRACTED IDEA
// ═══════════════════════════════════════════════════════════════

function applyCorrection(idea: ExtractedIdea, correction: string): ExtractedIdea {
  // If correction mentions specific competitors or industries, use them to refine the search
  const corrected = { ...idea };
  
  // Add correction text as additional context in description
  if (correction.trim().length > 0) {
    corrected.description = `${corrected.description}\n\nДополнительный контекст от пользователя: ${correction}`;
  }
  
  // Try to extract industry from correction
  const industryPatterns = [
    /(?:отрасль|сфера|рынок)[а-яё]*\s*[—–:]?\s*([а-яёa-z\s]{3,40})/gi,
    /в\s+(?:отрасли|сфере|рынке)\s+([а-яёa-z\s]{3,40})/gi,
  ];
  
  for (const pattern of industryPatterns) {
    const match = correction.match(pattern);
    if (match && match[1]) {
      const trimmed = match[1].trim();
      if (trimmed.length > 3 && !corrected.industry.includes(trimmed)) {
        corrected.industry = trimmed;
        break;
      }
    }
  }
  
  return corrected;
}
